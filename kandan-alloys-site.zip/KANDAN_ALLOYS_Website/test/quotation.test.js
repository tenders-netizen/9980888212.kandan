// Quotation Management Unit Tests

describe('Quotation Management', () => {
  let quotationForm;
  let companySearchInput;
  let quotationItems;
  
  beforeEach(() => {
    document.body.innerHTML = `
      <form id="quotationForm">
        <input type="text" id="companySearchInput">
        <input type="text" name="billingName">
        <input type="text" name="refNo" value="14327">
        <input type="date" name="invoiceDate">
        <tbody id="quotationItems">
          <tr>
            <td><input type="text" name="item[]"></td>
            <td><input type="text" name="hsnCode[]"></td>
            <td><input type="text" name="description[]"></td>
            <td><input type="number" name="qty[]"></td>
            <td><select name="unit[]"><option value="PCS">PCS</option></select></td>
            <td><input type="number" name="price[]"></td>
            <td><input type="number" name="discount[]"></td>
            <td><select name="tax[]"><option value="18">18%</option></select></td>
            <td><input type="number" name="amount[]" readonly></td>
          </tr>
        </tbody>
      </form>
    `;
    quotationForm = document.getElementById('quotationForm');
    companySearchInput = document.getElementById('companySearchInput');
    quotationItems = document.getElementById('quotationItems');
  });

  test('Company search input should trigger search results', () => {
    const mockCompanies = [
      { name: 'Test Company 1', phone: '1234567890' },
      { name: 'Test Company 2', phone: '0987654321' }
    ];
    
    // Mock the search function
    global.searchCompanies = jest.fn().mockResolvedValue(mockCompanies);
    
    // Trigger search
    companySearchInput.value = 'Test';
    companySearchInput.dispatchEvent(new Event('input'));
    
    expect(global.searchCompanies).toHaveBeenCalledWith('Test');
  });

  test('Amount calculation should be correct', () => {
    const row = quotationItems.querySelector('tr');
    const qtyInput = row.querySelector('input[name="qty[]"]');
    const priceInput = row.querySelector('input[name="price[]"]');
    const discountInput = row.querySelector('input[name="discount[]"]');
    const taxSelect = row.querySelector('select[name="tax[]"]');
    const amountInput = row.querySelector('input[name="amount[]"]');

    // Set test values
    qtyInput.value = '10';
    priceInput.value = '100';
    discountInput.value = '10';
    taxSelect.value = '18';

    // Trigger calculation
    const event = new Event('input');
    qtyInput.dispatchEvent(event);
    
    // Calculate expected amount: (qty * price) * (1 - discount/100) * (1 + tax/100)
    const expected = (10 * 100) * (1 - 10/100) * (1 + 18/100);
    
    expect(parseFloat(amountInput.value)).toBe(expected);
  });

  test('Form validation should work correctly', () => {
    const submitQuotation = () => {
      const formData = new FormData(quotationForm);
      return formData.get('invoiceDate') !== '' && 
             formData.get('item[]') !== '' && 
             formData.get('qty[]') > 0 && 
             formData.get('price[]') > 0;
    };

    expect(submitQuotation()).toBe(false);

    // Fill required fields
    quotationForm.querySelector('input[name="invoiceDate"]').value = '2024-01-20';
    quotationForm.querySelector('input[name="item[]"]').value = 'Test Item';
    quotationForm.querySelector('input[name="qty[]"]').value = '1';
    quotationForm.querySelector('input[name="price[]"]').value = '100';

    expect(submitQuotation()).toBe(true);
  });

  test('Adding new row should work', () => {
    const initialRowCount = quotationItems.querySelectorAll('tr').length;
    
    // Mock the addQuotationRow function
    global.addQuotationRow = () => {
      const newRow = quotationItems.querySelector('tr').cloneNode(true);
      quotationItems.appendChild(newRow);
    };

    global.addQuotationRow();
    
    const newRowCount = quotationItems.querySelectorAll('tr').length;
    expect(newRowCount).toBe(initialRowCount + 1);
  });
});